package com.termux.app.aerochat;

/**
 * A single bubble shown in the AeroChat chat panel.
 *
 * {@link #TYPE_USER} is a command the user typed and sent to the shell.
 * {@link #TYPE_OUTPUT} is the raw terminal output produced by that command. While the
 * command is still producing output (e.g. a long running or interactive program) the
 * bubble is marked {@link #pending} and its text keeps growing in place, like a message
 * that is still being "typed".
 * {@link #TYPE_AI} is an optional explanation/suggestion added by the configured AI
 * assistant once the output has settled.
 */
public class ChatMessage {

    public static final int TYPE_USER = 0;
    public static final int TYPE_OUTPUT = 1;
    public static final int TYPE_AI = 2;

    public final int type;
    public String text;
    public final long timestamp;

    /** True while an output bubble is still receiving new terminal data. */
    public boolean pending;

    public ChatMessage(int type, String text) {
        this.type = type;
        this.text = text;
        this.timestamp = System.currentTimeMillis();
    }
}
