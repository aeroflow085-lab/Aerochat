package com.termux.app.aerochat;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns a handful of common Spanish requests into the Termux command that does them, so the
 * chat feels like a conversation ("quiero ver mis archivos") rather than requiring the user to
 * already know shell syntax ("ls -la"). This runs locally, instantly, with no AI and no network.
 * <p>
 * If nothing here matches, {@link #translate} returns null and the caller decides what to do
 * next (ask the configured AI to translate it, or just run the text as typed).
 */
public final class NaturalLanguageCommandMapper {

    private static final Pattern INSTALL_PATTERN =
        Pattern.compile("(?i)\\binstala(?:r)?\\s+(?:el paquete\\s+|la app\\s+)?(.+)");

    private NaturalLanguageCommandMapper() {}

    public static String translate(String rawText) {
        if (rawText == null) return null;
        String text = normalize(rawText);
        if (text.isEmpty()) return null;

        Matcher installMatcher = INSTALL_PATTERN.matcher(text);
        if (installMatcher.matches()) {
            String pkg = installMatcher.group(1).trim().replaceAll("\\s+", " ");
            pkg = pkg.replaceAll("(?i)\\s*(por favor|porfa)$", "").trim();
            if (!pkg.isEmpty() && !pkg.contains(" ")) {
                return "pkg install " + pkg + " -y";
            }
        }

        if (contains(text, "hora es", "qué hora", "que hora")) return "date";
        if (contains(text, "qué día", "que dia", "fecha de hoy", "qué fecha", "que fecha")) return "date";

        if (contains(text, "ver mis archivos", "ver archivos", "mostrar archivos", "lista de archivos",
                "listar archivos", "qué hay en esta carpeta", "que hay en esta carpeta", "qué hay aquí", "que hay aqui")) {
            return "ls -la";
        }

        if (contains(text, "dónde estoy", "donde estoy", "en qué carpeta", "en que carpeta", "ruta actual",
                "carpeta actual")) {
            return "pwd";
        }

        if (contains(text, "quién soy", "quien soy", "mi usuario", "cuál es mi usuario", "cual es mi usuario")) {
            return "whoami";
        }

        if (contains(text, "actualiza", "actualizar")) {
            return "pkg update -y && pkg upgrade -y";
        }

        if (contains(text, "limpia la pantalla", "limpiar pantalla", "borra la pantalla", "borrar pantalla")) {
            return "clear";
        }

        if (contains(text, "espacio en disco", "espacio de almacenamiento", "cuánto espacio", "cuanto espacio")) {
            return "df -h";
        }

        if (contains(text, "memoria ram", "uso de memoria", "cuánta memoria", "cuanta memoria")) {
            return "free -h";
        }

        if (contains(text, "mi ip", "dirección ip", "direccion ip", "cuál es mi ip", "cual es mi ip")) {
            return "curl -s ifconfig.me; echo";
        }

        if (contains(text, "batería", "bateria", "nivel de batería", "nivel de bateria")) {
            return "termux-battery-status";
        }

        if (contains(text, "qué paquetes tengo", "que paquetes tengo", "paquetes instalados")) {
            return "pkg list-installed";
        }

        return null;
    }

    private static boolean contains(String text, String... anyOf) {
        for (String phrase : anyOf) {
            if (text.contains(phrase)) return true;
        }
        return false;
    }

    private static String normalize(String text) {
        return text.trim().toLowerCase();
    }
}
