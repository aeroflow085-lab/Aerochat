package com.termux.app.activities;

import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.termux.R;
import com.termux.app.aerochat.AiPreferences;
import com.termux.shared.activity.media.AppCompatActivityUtils;
import com.termux.shared.theme.NightMode;

/**
 * Lets the user turn the AeroChat AI assistant on/off, pick a provider and paste their own
 * API key. Everything is stored locally via {@link AiPreferences} and "Eliminar clave" wipes
 * it completely at any time.
 */
public class AiAssistantSettingsActivity extends AppCompatActivity {

    private Switch mEnableSwitch;
    private RadioGroup mProviderGroup;
    private EditText mBaseUrlEditText;
    private EditText mModelEditText;
    private EditText mApiKeyEditText;
    private boolean mKeyVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatActivityUtils.setNightMode(this, NightMode.getAppNightMode().getName(), true);
        setContentView(R.layout.activity_ai_assistant_settings);

        mEnableSwitch = findViewById(R.id.ai_enable_switch);
        mProviderGroup = findViewById(R.id.ai_provider_radio_group);
        mBaseUrlEditText = findViewById(R.id.ai_base_url_edittext);
        mModelEditText = findViewById(R.id.ai_model_edittext);
        mApiKeyEditText = findViewById(R.id.ai_api_key_edittext);
        ImageButton toggleVisibilityButton = findViewById(R.id.ai_api_key_toggle_visibility);

        loadCurrentValues();

        toggleVisibilityButton.setOnClickListener(v -> {
            mKeyVisible = !mKeyVisible;
            int cursor = mApiKeyEditText.getSelectionStart();
            mApiKeyEditText.setInputType(mKeyVisible
                ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            if (cursor >= 0) mApiKeyEditText.setSelection(cursor);
        });

        mProviderGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.ai_provider_gemini) {
                mBaseUrlEditText.setEnabled(false);
                if (mModelEditText.getText().toString().trim().isEmpty()) {
                    mModelEditText.setHint(AiPreferences.DEFAULT_GEMINI_MODEL);
                }
            } else {
                mBaseUrlEditText.setEnabled(true);
            }
        });

        findViewById(R.id.ai_save_button).setOnClickListener(v -> saveAndFinish());
        findViewById(R.id.ai_clear_key_button).setOnClickListener(v -> clearKey());

        AppCompatActivityUtils.setToolbar(this, com.termux.shared.R.id.toolbar);
        AppCompatActivityUtils.setShowBackButtonInActionBar(this, true);
    }

    private void loadCurrentValues() {
        mEnableSwitch.setChecked(AiPreferences.isEnabled(this));

        boolean isGemini = AiPreferences.PROVIDER_GEMINI.equals(AiPreferences.getProvider(this));
        mProviderGroup.check(isGemini ? R.id.ai_provider_gemini : R.id.ai_provider_openai);
        mBaseUrlEditText.setEnabled(!isGemini);

        String storedBaseUrl = AiPreferences.getBaseUrl(this);
        if (!AiPreferences.DEFAULT_OPENAI_BASE_URL.equals(storedBaseUrl) || !isGemini) {
            mBaseUrlEditText.setText(storedBaseUrl);
        }
        mModelEditText.setHint(isGemini ? AiPreferences.DEFAULT_GEMINI_MODEL : AiPreferences.DEFAULT_OPENAI_MODEL);
        String storedModel = AiPreferences.getModel(this);
        mModelEditText.setText(storedModel);
        mApiKeyEditText.setText(AiPreferences.getApiKey(this));
    }

    private void saveAndFinish() {
        String apiKey = mApiKeyEditText.getText().toString().trim();
        boolean wantsEnabled = mEnableSwitch.isChecked();

        if (wantsEnabled && apiKey.isEmpty()) {
            Toast.makeText(this, R.string.ai_missing_key_toast, Toast.LENGTH_LONG).show();
            return;
        }

        String provider = mProviderGroup.getCheckedRadioButtonId() == R.id.ai_provider_gemini
            ? AiPreferences.PROVIDER_GEMINI : AiPreferences.PROVIDER_OPENAI;

        AiPreferences.save(this,
            wantsEnabled,
            provider,
            mBaseUrlEditText.getText().toString(),
            mModelEditText.getText().toString(),
            apiKey);

        Toast.makeText(this, R.string.ai_saved_toast, Toast.LENGTH_SHORT).show();
        finish();
    }

    private void clearKey() {
        AiPreferences.clearApiKey(this);
        mApiKeyEditText.setText("");
        mEnableSwitch.setChecked(false);
        Toast.makeText(this, R.string.ai_key_cleared_toast, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
