package com.termux.app.aerochat;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Sends a command + its terminal output to the AI provider the user configured in
 * {@link com.termux.app.activities.AiAssistantSettingsActivity}, and returns a short
 * explanation/suggestion. Runs entirely off the main thread; never throws to the caller,
 * errors are reported through {@link Callback#onError(String)} instead.
 */
public class AiAssistantClient {

    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());
    private static final int TIMEOUT_MS = 20000;

    public interface Callback {
        void onResult(String text);
        void onError(String message);
    }

    private static final String SYSTEM_PROMPT =
        "Eres un asistente dentro de una app de terminal para Android llamada AeroChat. " +
        "El usuario te muestra un comando de shell y lo que imprimió. " +
        "Responde en espanol, muy breve (maximo 4 lineas): explica que hizo el comando o, " +
        "si hubo un error, di cual fue la causa probable y el comando corregido. " +
        "No repitas la salida completa.";

    public static void ask(Context context, String command, String output, Callback callback) {
        final Context appContext = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            try {
                String result = doAsk(appContext, command, output);
                postResult(callback, result);
            } catch (Exception e) {
                postError(callback, e.getMessage() == null ? e.toString() : e.getMessage());
            }
        });
    }

    private static String doAsk(Context context, String command, String output) throws Exception {
        String provider = AiPreferences.getProvider(context);
        String apiKey = AiPreferences.getApiKey(context);
        if (apiKey.isEmpty()) throw new IllegalStateException("no-api-key");

        String userContent = "Comando:\n" + command + "\n\nSalida:\n" + truncate(output, 4000);

        if (AiPreferences.PROVIDER_GEMINI.equals(provider)) {
            return askGemini(apiKey, AiPreferences.getModel(context), userContent);
        } else {
            return askOpenAiCompatible(AiPreferences.getBaseUrl(context), apiKey, AiPreferences.getModel(context), userContent);
        }
    }

    private static String askOpenAiCompatible(String baseUrl, String apiKey, String model, String userContent) throws Exception {
        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("max_tokens", 300);

        JSONArray messages = new JSONArray();
        JSONObject systemMsg = new JSONObject();
        systemMsg.put("role", "system");
        systemMsg.put("content", SYSTEM_PROMPT);
        messages.put(systemMsg);

        JSONObject userMsg = new JSONObject();
        userMsg.put("role", "user");
        userMsg.put("content", userContent);
        messages.put(userMsg);

        body.put("messages", messages);

        String responseBody = httpPost(baseUrl, body.toString(), conn ->
            conn.setRequestProperty("Authorization", "Bearer " + apiKey));

        JSONObject json = new JSONObject(responseBody);
        if (json.has("error")) {
            throw new IOException(json.getJSONObject("error").optString("message", "error de la API"));
        }
        return json.getJSONArray("choices")
            .getJSONObject(0)
            .getJSONObject("message")
            .getString("content")
            .trim();
    }

    private static String askGemini(String apiKey, String model, String userContent) throws Exception {
        String url = "https://generativelanguage.googleapis.com/v1beta/models/" + model
            + ":generateContent?key=" + apiKey;

        JSONObject part = new JSONObject();
        part.put("text", SYSTEM_PROMPT + "\n\n" + userContent);
        JSONArray parts = new JSONArray().put(part);
        JSONObject content = new JSONObject().put("parts", parts);
        JSONObject body = new JSONObject().put("contents", new JSONArray().put(content));

        String responseBody = httpPost(url, body.toString(), conn -> {});

        JSONObject json = new JSONObject(responseBody);
        if (json.has("error")) {
            throw new IOException(json.getJSONObject("error").optString("message", "error de la API"));
        }
        return json.getJSONArray("candidates")
            .getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")
            .getJSONObject(0)
            .getString("text")
            .trim();
    }

    private interface ConnConfigurer {
        void configure(HttpURLConnection conn);
    }

    private static String httpPost(String urlString, String jsonBody, ConnConfigurer configurer) throws IOException {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(TIMEOUT_MS);
            conn.setReadTimeout(TIMEOUT_MS);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            configurer.configure(conn);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(jsonBody.getBytes(StandardCharsets.UTF_8));
            }

            int code = conn.getResponseCode();
            InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            String responseBody = readStream(stream);
            if (code < 200 || code >= 300) {
                throw new IOException("HTTP " + code + ": " + truncate(responseBody, 300));
            }
            return responseBody;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String readStream(InputStream stream) throws IOException {
        if (stream == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private static String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    private static void postResult(Callback callback, String result) {
        MAIN_HANDLER.post(() -> callback.onResult(result));
    }

    private static void postError(Callback callback, String message) {
        MAIN_HANDLER.post(() -> callback.onError(message));
    }
}
