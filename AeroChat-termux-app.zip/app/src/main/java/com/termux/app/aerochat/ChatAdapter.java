package com.termux.app.aerochat;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.termux.R;

import java.util.ArrayList;
import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.BubbleViewHolder> {

    private final List<ChatMessage> mMessages = new ArrayList<>();

    public List<ChatMessage> getMessages() {
        return mMessages;
    }

    public void addMessage(ChatMessage message) {
        mMessages.add(message);
        notifyItemInserted(mMessages.size() - 1);
    }

    public void updateLast(ChatMessage message) {
        if (mMessages.isEmpty()) return;
        notifyItemChanged(mMessages.size() - 1);
    }

    public void removeLast() {
        if (mMessages.isEmpty()) return;
        int index = mMessages.size() - 1;
        mMessages.remove(index);
        notifyItemRemoved(index);
    }

    public void clear() {
        int size = mMessages.size();
        mMessages.clear();
        if (size > 0) notifyItemRangeRemoved(0, size);
    }

    @Override
    public int getItemViewType(int position) {
        return mMessages.get(position).type;
    }

    @Override
    public int getItemCount() {
        return mMessages.size();
    }

    @NonNull
    @Override
    public BubbleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layoutRes;
        if (viewType == ChatMessage.TYPE_USER) {
            layoutRes = R.layout.item_chat_user;
        } else if (viewType == ChatMessage.TYPE_AI) {
            layoutRes = R.layout.item_chat_ai;
        } else {
            layoutRes = R.layout.item_chat_output;
        }
        View view = LayoutInflater.from(parent.getContext()).inflate(layoutRes, parent, false);
        return new BubbleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BubbleViewHolder holder, int position) {
        ChatMessage message = mMessages.get(position);
        String text = message.text == null ? "" : message.text;
        if (message.type != ChatMessage.TYPE_USER && message.pending && !text.isEmpty()) {
            text = text + " \u258a"; // trailing block cursor while output is still streaming
        }
        holder.textView.setText(text);
    }

    static class BubbleViewHolder extends RecyclerView.ViewHolder {
        final TextView textView;

        BubbleViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.chat_item_text);
        }
    }
}
